from src.headers import *
from src.person import Person


class spell(Person):
    def __init__(self) :
        print()

       
